#pragma once
#ifndef APP_H_
#define APP_H_

void appStart(void);

#endif
