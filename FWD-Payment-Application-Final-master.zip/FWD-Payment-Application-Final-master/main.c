#include <stdio.h>
#include "terminal.h"
#include "card.h"
#include "server.h"
#include "app.h"
#include<time.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

struct a {

	char studentname[50];
	int seatNumber;
	int age;

};

int main() {
		appStart();
	
}